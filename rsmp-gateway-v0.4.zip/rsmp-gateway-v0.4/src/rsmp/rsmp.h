#ifndef RSMP_RSMP_H
#define RSMP_RSMP_H

#include "log/log.h"
#include "errcode/errcode.h"
// #include "rsmp/messages/messages.h"
// #include "rsmp/coder/json.h"

// #include "cyber/cyber.h"
// typedef struct rsmp_engine rsmp_engine_t; // \todo voir pour remonter l'objet cyber_t dans un (e)rsmp_engine_t
// #define rsmp_engine_t cyber_t

#endif