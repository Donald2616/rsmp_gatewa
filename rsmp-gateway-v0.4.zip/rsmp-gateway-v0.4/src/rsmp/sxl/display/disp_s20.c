/**
 * @file disp_s20.c
 * @brief Ce fichier ne contient aucune fonction. Il est uniquement destiné à centraliser les structures DISP/S20.
 *
 * L'encodage et le décodage JSON de ces structures est géré dans `disp_json_generic.c`.
 */

 #include "disp_s20.h"

 // Ce fichier est intentionnellement vide.
 