#ifndef TEST_RSMP_SXL_H
#define TEST_RSMP_SXL_H
void test_rsmp_sxl(void);

#endif //TEST_RSMP_MESSAGES_H