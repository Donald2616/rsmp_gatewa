#ifndef TEST_RSMP_MESSAGES_H
#define TEST_RSMP_MESSAGES_H
void test_rsmp_messages(void);

#endif //TEST_RSMP_MESSAGES_H